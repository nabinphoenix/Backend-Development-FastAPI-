import time

def send_welcome_email(user_email: str, username: str):
    """Simple background task to send welcome email"""
    time.sleep(2)  # Simulate email sending delay
    print(f'📧 Sending welcome email to {user_email} for user {username}')

def send_account_deletion_email(user_email: str, username: str):
    """Simple background task to send account deletion email"""
    time.sleep(1)  # Simulate email sending delay
    print(f'📧 Sending account deletion email to {user_email} for user {username}')
