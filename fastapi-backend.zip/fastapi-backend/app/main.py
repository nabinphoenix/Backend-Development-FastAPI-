from fastapi import FastAPI, Depends, HTTPException, status, BackgroundTasks
from sqlmodel.ext.asyncio.session import AsyncSession
from app.db.database import get_session
from app.schemas.user import UserCreate, UserRead, UserLogin, Token, DeleteResponse, UserUpdate, UserUpdateWithPassword, UserDeleteWithPassword
from app.schemas.todo import TodoCreate, TodoRead
from app.db.crud import user as user_crud, todo as todo_crud
from app.auth.dependencies import get_current_active_superuser, get_current_normal_user
from app.auth.security import verify_password, create_access_token, verify_token
from app.core.init_superuser import create_first_superuser
from fastapi.security import OAuth2PasswordRequestForm, OAuth2PasswordBearer
from background_tasks.email_tasks import send_welcome_email, send_account_deletion_email



app = FastAPI(
    title="FastAPI ToDo App", 
    version="1.0.0",
    description="A FastAPI application for managing todos with user authentication and authorization"
)

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="login")

# ---------- User Endpoints ----------
@app.on_event("startup")
async def startup_event():
    await create_first_superuser()


@app.post("/register", response_model=UserRead, tags=["Authentication"])
async def register(
    user: UserCreate, 
    background_tasks: BackgroundTasks,
    session: AsyncSession = Depends(get_session)
):
    """
    **Signup** - Register a new user account
    """
    db_user = await user_crud.get_user_by_username(session, user.username)
    if db_user:
        raise HTTPException(status_code=400, detail="Username already exists")
    new_user = await user_crud.create_user(session, user.username, user.email, user.password)
    
    # Add background task to send welcome email
    background_tasks.add_task(send_welcome_email, user.email, user.username)
    
    return new_user



@app.post("/login", response_model=Token, tags=["Authentication"])
async def login(
    form_data: OAuth2PasswordRequestForm = Depends(),
    session: AsyncSession = Depends(get_session),
):
    """
    **Login** - Authenticate user and get access token
    """
    db_user = await user_crud.get_user_by_username(session, form_data.username)
    if not db_user or not verify_password(form_data.password, db_user.hashed_password):
        raise HTTPException(status_code=401, detail="Invalid credentials")

    access_token = create_access_token({"sub": db_user.username}, expires_minutes=15)
    refresh_token = create_access_token({"sub": db_user.username}, expires_minutes=60 * 24 * 7)  # 7 days

    return {
        "access_token": access_token,
        "refresh_token": refresh_token,
        "token_type": "bearer"
    }


@app.get("/users/me", response_model=UserRead, tags=["User"])
async def read_current_user(current_user=Depends(get_current_normal_user)):
    """
    Get current user profile
    """
    return current_user


@app.put("/users/me", response_model=UserRead, tags=["User"])
async def update_current_user(
    user_update: UserUpdateWithPassword, 
    session: AsyncSession = Depends(get_session), 
    current_user=Depends(get_current_normal_user)
):
    """
    Update current user profile (requires current password)
    """
    # Verify current password
    if not verify_password(user_update.current_password, current_user.hashed_password):
        raise HTTPException(status_code=400, detail="Current password is incorrect")
    
    # Check if username is being changed and if it already exists
    if user_update.username and user_update.username != current_user.username:
        existing_user = await user_crud.get_user_by_username(session, user_update.username)
        if existing_user:
            raise HTTPException(status_code=400, detail="Username already exists")
    
    updated_user = await user_crud.update_user(
        session, 
        current_user, 
        username=user_update.username,
        email=user_update.email,
        password=user_update.new_password
    )
    return updated_user


@app.delete("/users/me", response_model=DeleteResponse, tags=["User"])
async def delete_current_user(
    user_delete: UserDeleteWithPassword,
    background_tasks: BackgroundTasks,
    session: AsyncSession = Depends(get_session), 
    current_user=Depends(get_current_normal_user)
):
    """
    Delete current user account (requires current password)
    """
    # Verify current password
    if not verify_password(user_delete.current_password, current_user.hashed_password):
        raise HTTPException(status_code=400, detail="Current password is incorrect")
    
    # Store user info before deletion for background task
    user_email = current_user.email
    username = current_user.username
    
    await user_crud.delete_user(session, current_user)
    
    # Add background task to send account deletion confirmation email
    background_tasks.add_task(send_account_deletion_email, user_email, username)
    
    return DeleteResponse(message="Your account has been successfully deleted")


@app.get("/users", response_model=list[UserRead], tags=["Admin"])
async def read_all_users(session: AsyncSession = Depends(get_session), current_user=Depends(get_current_active_superuser)):
    """
    **Admin Only** - Read all users in the system
    """
    return await user_crud.list_users(session)


@app.get("/users/{user_id}", response_model=UserRead, tags=["Admin"])
async def read_user(user_id: int, session: AsyncSession = Depends(get_session), current_user=Depends(get_current_active_superuser)):
    """
    **Admin Only** - Get a specific user by ID
    """
    user = await user_crud.get_user_by_id(session, user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return user


@app.post("/users", response_model=UserRead, tags=["Admin"])
async def create_user_admin(user: UserCreate, session: AsyncSession = Depends(get_session), current_user=Depends(get_current_active_superuser)):
    """
    **Admin Only** - Create a new user (admin can create users without registration)
    """
    db_user = await user_crud.get_user_by_username(session, user.username)
    if db_user:
        raise HTTPException(status_code=400, detail="Username already exists")
    new_user = await user_crud.create_user(session, user.username, user.email, user.password)
    return new_user


@app.put("/users/{user_id}", response_model=UserRead, tags=["Admin"])
async def update_a_user_by_id(
    user_id: int, 
    user_update: UserUpdate, 
    session: AsyncSession = Depends(get_session), 
    current_user=Depends(get_current_active_superuser)
):
    """
    **Admin Only** - Update a user by ID
    """
    db_user = await user_crud.get_user_by_id(session, user_id)
    if not db_user:
        raise HTTPException(status_code=404, detail="User not found")
    
    # Check if username is being changed and if it already exists
    if user_update.username and user_update.username != db_user.username:
        existing_user = await user_crud.get_user_by_username(session, user_update.username)
        if existing_user:
            raise HTTPException(status_code=400, detail="Username already exists")
    
    updated_user = await user_crud.update_user(
        session, 
        db_user, 
        username=user_update.username,
        email=user_update.email,
        password=user_update.password
    )
    return updated_user


@app.delete("/users/{user_id}", response_model=DeleteResponse, tags=["Admin"])
async def delete_a_user_by_id(user_id: int, session: AsyncSession = Depends(get_session), current_user=Depends(get_current_active_superuser)):
    """
    **Admin Only** - Delete a user by ID
    """
    db_user = await user_crud.get_user_by_id(session, user_id)
    if not db_user:
        raise HTTPException(status_code=404, detail="User not found")
    
    # Prevent admin from deleting themselves
    if db_user.id == current_user.id:
        raise HTTPException(status_code=400, detail="Cannot delete your own account")
    
    await user_crud.delete_user(session, db_user)
    return DeleteResponse(message=f"User with ID {user_id} has been successfully deleted")

# ---------- Todo Endpoints ----------

@app.post("/todos", response_model=TodoRead, tags=["Todo"])
async def create_todo(todo: TodoCreate, session: AsyncSession = Depends(get_session), current_user=Depends(get_current_normal_user)):
    """
    Create a new todo item
    """
    return await todo_crud.create_todo(session, todo.title, todo.description, current_user.id)

@app.get("/todos", response_model=list[TodoRead], tags=["Todo"])
async def read_user_todos(session: AsyncSession = Depends(get_session), current_user=Depends(get_current_normal_user)):
    """
    Get all todos for the current user
    """
    return await todo_crud.list_user_todos(session, current_user.id)

@app.get("/todos/all", response_model=list[TodoRead], tags=["Admin"])
async def read_all_todos(session: AsyncSession = Depends(get_session), current_user=Depends(get_current_active_superuser)):
    """
    **Admin Only** - Read all todos from all users
    """
    return await todo_crud.list_all_todos(session)

@app.put("/todos/{todo_id}", response_model=TodoRead, tags=["Todo"])
async def update_todo(todo_id: int, todo: TodoCreate, session: AsyncSession = Depends(get_session), current_user=Depends(get_current_normal_user)):
    """
    Update a todo item (only if owned by current user)
    """
    db_todo = await todo_crud.get_todo(session, todo_id)
    if not db_todo or db_todo.user_id != current_user.id:
        raise HTTPException(status_code=404, detail="Todo not found")
    return await todo_crud.update_todo(session, db_todo, todo.title, todo.description, todo.completed)

@app.delete("/todos/{todo_id}", response_model=DeleteResponse, tags=["Todo"])
async def delete_todo(todo_id: int, session: AsyncSession = Depends(get_session), current_user=Depends(get_current_normal_user)):
    """
    Delete a todo item (only if owned by current user)
    """
    db_todo = await todo_crud.get_todo(session, todo_id)
    if not db_todo or db_todo.user_id != current_user.id:
        raise HTTPException(status_code=404, detail="Todo not found")
    await todo_crud.delete_todo(session, db_todo)
    return DeleteResponse(message=f"Todo with ID {todo_id} has been successfully deleted")
